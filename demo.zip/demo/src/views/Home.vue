<template>
    <div class="home-container">
        <!-- 空白页面，可添加提示文字 -->
        <div class="empty-hint">请从左侧菜单选择操作</div>
    </div>
</template>

<script setup>
</script>

<style scoped>
.home-container {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
    font-size: 16px;
}
</style>