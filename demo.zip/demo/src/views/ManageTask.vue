<template>
    <div class="production-management">
        <div class="page-header">
            <h1>班次管理</h1>
            <p>查看和管理不同班次的生产任务及金额统计</p>
        </div>

        <div class="dashboard-container">
            <!-- 班次选择区域 -->
            <div class="shift-selector">
                <p>选择班次:</p>
                <el-radio-group v-model="selectedShift" @change="handleShiftChange">
                    <el-radio-button label="早班" />
                    <el-radio-button label="中班" />
                    <el-radio-button label="晚班" />
                </el-radio-group>
            </div>

            <!-- 班次信息卡片 -->
            <div class="shift-info-card">
                <div class="info-item">
                    <p class="info-label">当前班次总金额</p>
                    <p class="total-amount">{{ formatCurrency(shiftInfo.totalAmount) }} 元</p>
                </div>
                <div class="info-stats">
                    <p>任务数: {{ shiftInfo.totalTasks }}</p>
                    <p>未完成: {{ shiftInfo.unfinishedTasks }}</p>
                </div>
            </div>
        </div>

        <!-- 任务列表 -->
        <div class="task-list-container">
            <h2>{{ selectedShift }}任务列表</h2>
            <el-table :data="taskList" border style="width: 100%; margin-top: 10px">
                <el-table-column prop="taskId" label="任务编号" width="100" />
                <el-table-column prop="productType" label="生产类型" width="120" />
                <el-table-column prop="price" label="单价" width="120">
                    <template #default="scope">
                        {{ formatCurrency(scope.row.price) }} 元
                    </template>
                </el-table-column>
                <el-table-column prop="quantity" label="生产数量" width="120" />
                <el-table-column prop="startTime" label="起始时间" width="140" />
                <el-table-column prop="endTime" label="结束时间" width="140">
                    <template #default="scope">
                        <span :class="{
                            'text-processing': scope.row.endTime === '生产中',
                            'text-completed': scope.row.endTime && scope.row.endTime !== '生产中'
                        }">
                            {{ scope.row.endTime || '生产中' }}
                        </span>
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="100">
                    <template #default="scope">
                        <!-- 只有未完成的任务显示结束按钮 -->
                        <el-button v-if="!scope.row.endTime || scope.row.endTime === '生产中'" type="primary" size="small"
                            @click="handleFinishTask(scope.row)">
                            结束
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div class="task-count">
                <el-badge :value="shiftInfo.totalTasks" class="task-count-badge">
                    任务总数
                </el-badge>
            </div>
        </div>

        <!-- 结束任务对话框 -->
        <el-dialog title="结束生产任务" v-model="showFinishDialog" width="400px">
            <el-form :model="finishForm" :rules="finishRules" ref="finishFormRef" label-width="100px">
                <el-form-item label="任务编号">
                    <el-input v-model="finishForm.taskId" disabled />
                </el-form-item>
                <el-form-item label="生产类型">
                    <el-input v-model="finishForm.productType" disabled />
                </el-form-item>
                <el-form-item label="结束时间" prop="endTime">
                    <el-date-picker v-model="finishForm.endTime" type="datetime" placeholder="选择结束时间"
                        value-format="YYYY-MM-DD HH:mm:ss" />
                </el-form-item>
            </el-form>
            <template #footer>
                <el-button @click="showFinishDialog = false">取消</el-button>
                <el-button type="primary" @click="handleFinishSubmit">确定</el-button>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import productionApi from '@/api/production' // 导入生产相关API

// 选中的班次
const selectedShift = ref('早班')

// 班次信息
const shiftInfo = reactive({
    totalAmount: 0,      // 总金额
    totalTasks: 0,       // 总任务数
    unfinishedTasks: 0   // 未完成任务数
})

// 任务列表数据
const taskList = ref([])

// 结束任务对话框相关
const showFinishDialog = ref(false)
const currentTask = ref(null)
const finishForm = reactive({
    taskId: '',
    productType: '',
    endTime: ''
})
const finishFormRef = ref(null)
const finishRules = reactive({
    endTime: [
        { required: true, message: '请选择结束时间', trigger: 'change' }
    ]
})

// 页面加载时获取默认班次数据
onMounted(() => {
    fetchShiftData(selectedShift.value)
})

// 格式化金额显示
const formatCurrency = (value) => {
    if (!value) return '0'
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

// 获取班次数据
const fetchShiftData = async (shift) => {
    try {
        // 真实接口调用
        const response = await productionApi.getShiftData(shift)
        const data = response.data.data

        shiftInfo.totalAmount = data.totalAmount
        shiftInfo.totalTasks = data.totalTasks
        shiftInfo.unfinishedTasks = data.unfinishedTasks
        taskList.value = data.tasks

        ElMessage.success(`已加载${shift}数据`)
    } catch (error) {
        ElMessage.error('获取班次数据失败: ' + error.message)
    }
}

// 切换班次
const handleShiftChange = (shift) => {
    fetchShiftData(shift)
}

// 处理结束任务
const handleFinishTask = (row) => {
    currentTask.value = row
    finishForm.taskId = row.taskId
    finishForm.productType = row.productType
    finishForm.endTime = ''
    showFinishDialog.value = true
}

// 提交结束任务
const handleFinishSubmit = async () => {
    // 表单验证
    if (!finishFormRef.value) return
    const valid = await finishFormRef.value.validate()
    if (!valid) return

    try {
        // 真实接口调用
        await productionApi.finishTask({
            taskId: finishForm.taskId,
            endTime: finishForm.endTime
        })

        // 更新本地数据
        const taskIndex = taskList.value.findIndex(t => t.taskId === finishForm.taskId)
        if (taskIndex !== -1) {
            taskList.value[taskIndex].endTime = finishForm.endTime
            // 更新统计信息
            shiftInfo.unfinishedTasks--
        }

        showFinishDialog.value = false
        ElMessage.success('任务已成功结束')
    } catch (error) {
        ElMessage.error('结束任务失败: ' + error.message)
    }
}
</script>

<style scoped>
.production-management {
    padding: 20px;
    background-color: #fff;
    min-height: 100vh;
}

.page-header {
    margin-bottom: 20px;
}

.page-header h1 {
    font-size: 20px;
    margin-bottom: 8px;
    color: #333;
}

.page-header p {
    color: #666;
    font-size: 14px;
}

.dashboard-container {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
    align-items: flex-start;
}

.shift-selector {
    background-color: #f5f7fa;
    padding: 20px;
    border-radius: 4px;
    min-width: 200px;
}

.shift-selector p {
    margin-bottom: 15px;
    color: #666;
    font-weight: 500;
}

.shift-info-card {
    background-color: #f5f7fa;
    padding: 20px;
    border-radius: 4px;
    flex: 1;
    min-width: 300px;
}

.info-item {
    margin-bottom: 15px;
}

.info-label {
    color: #666;
    margin-bottom: 8px;
    font-size: 14px;
}

.total-amount {
    font-size: 28px;
    font-weight: bold;
    color: #27ae60;
    margin: 0;
}

.info-stats {
    display: flex;
    gap: 20px;
    color: #666;
}

.task-list-container {
    margin-top: 20px;
}

.task-list-container h2 {
    font-size: 16px;
    color: #333;
    margin-bottom: 10px;
}

.task-count {
    margin-top: 10px;
    text-align: right;
}

.task-count-badge {
    margin-left: 5px;
}

.text-processing {
    color: #e6a23c;
}

.text-completed {
    color: #27ae60;
}
</style>