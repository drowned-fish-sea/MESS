// src/api/task.js
import apiClient from '../permission'

/**
 * 获取任务列表
 * @param {Object} params - 查询参数
 * @returns {Promise} - 任务列表数据
 */
export function getTaskList(params) {
  return apiClient.get('/api/task/query', { params })
}

/**
 * 添加新任务
 * @param {Object} data - 任务数据
 * @returns {Promise} - 操作结果
 */
export function addTask(data) {
  return apiClient.post('/api/task/create', data)
}

/**
 * 更新任务信息
 * @param {string} id - 任务ID
 * @param {Object} data - 更新的任务数据
 * @returns {Promise} - 操作结果
 */
export function updateTask(id, data) {
  return apiClient.put(`/api/task/update/${id}`, data)
}

/**
 * 删除任务
 * @param {string} id - 任务ID
 * @returns {Promise} - 操作结果
 */
export function deleteTask(id) {
  return apiClient.delete(`/api/task/delete/${id}`)
}

/**
 * 指派任务
 * @param {string} id - 任务ID
 * @param {Object} data - 指派信息
 * @returns {Promise} - 操作结果
 */
export function assignTask(id, data) {
  return apiClient.post(`/api/task/assign/${id}/assign`, data)
}

/**
 * 搜索任务
 * @param {Object} params - 搜索参数
 * @returns {Promise} - 搜索结果
 */
export function searchTasks(params) {
  return apiClient.get('/api/task/query', { params })
}

export default {
  getTaskList,
  addTask,
  updateTask,
  deleteTask,
  assignTask,
  searchTasks
}