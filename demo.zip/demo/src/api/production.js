// src/api/production.js
import apiClient from '../permission'

/**
 * 获取指定班次的数据
 * @param {string} shift - 班次名称（早班/中班/晚班）
 * @returns {Promise} - 包含班次数据的Promise
 */
export function getShiftData(shift) {
  return apiClient.get('/api/task//query', {
    params: { shift }
  })
}

/**
 * 结束指定任务
 * @param {Object} data - 结束任务的数据
 * @param {string} data.taskId - 任务编号
 * @param {string} data.endTime - 结束时间（YYYY-MM-DD）
 * @returns {Promise} - 操作结果的Promise
 */
export function finishTask(data) {
  return apiClient.post('/api/task/finish', data)
}

export default {
  getShiftData,
  finishTask
}