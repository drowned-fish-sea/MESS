// src/store/productionStore.js
import { defineStore } from 'pinia'
import { getShiftData, finishTask } from '@/api/production'
import { ElMessage } from 'element-plus'

export const useProductionStore = defineStore('production', () => {
  // 可以在这里添加需要全局管理的状态
  // 例如：当前选中的班次、缓存的班次数据等

  /**
   * 获取指定班次的数据
   * @param {string} shift - 班次名称
   * @returns {Promise<Object>} - 班次数据
   */
  async function fetchShiftData(shift) {
    try {
      const response = await getShiftData(shift)
      if (response.data.code === 1) {
        return response.data.data
      } else {
        ElMessage.error(response.data.msg || '获取班次数据失败')
        return null
      }
    } catch (error) {
      ElMessage.error('获取班次数据失败: ' + error.message)
      return null
    }
  }

  /**
   * 结束指定任务
   * @param {Object} data - 结束任务的数据
   * @returns {Promise<boolean>} - 是否成功
   */
  async function completeTask(data) {
    try {
      const response = await finishTask(data)
      if (response.data.code === 1) {
        ElMessage.success('任务已结束')
        return true
      } else {
        ElMessage.error(response.data.msg || '结束任务失败')
        return false
      }
    } catch (error) {
      ElMessage.error('结束任务失败: ' + error.message)
      return false
    }
  }

  return {
    fetchShiftData,
    completeTask
  }
})