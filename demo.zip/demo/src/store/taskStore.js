// src/store/taskStore.js
import { defineStore } from 'pinia'
import { getTaskList, addTask, updateTask, deleteTask, assignTask, searchTasks } from '@/api/task'
import { ElMessage } from 'element-plus'
import { ref } from 'vue'
export const useTaskStore = defineStore('task', () => {
  const taskList = ref([])
  const loading = ref(false)

  /**
   * 获取任务列表
   * @param {Object} params - 查询参数
   * @returns {Promise<boolean>} - 是否成功
   */
  async function fetchTaskList(params = {}) {
    loading.value = true
    try {
      const response = await getTaskList(params)
      if (response.data.code === 1) {
        taskList.value = response.data.data
        return true
      } else {
        ElMessage.error(response.data.msg || '获取任务列表失败')
        return false
      }
    } catch (error) {
      ElMessage.error('获取任务列表失败: ' + error.message)
      return false
    } finally {
      loading.value = false
    }
  }

  /**
   * 添加任务
   * @param {Object} data - 任务数据
   * @returns {Promise<boolean>} - 是否成功
   */
  async function addNewTask(data) {
    try {
      const response = await addTask(data)
      if (response.data.code === 1) {
        ElMessage.success('任务添加成功')
        return true
      } else {
        ElMessage.error(response.data.msg || '添加任务失败')
        return false
      }
    } catch (error) {
      ElMessage.error('添加任务失败: ' + error.message)
      return false
    }
  }

  /**
   * 更新任务
   * @param {string} id - 任务ID
   * @param {Object} data - 任务数据
   * @returns {Promise<boolean>} - 是否成功
   */
  async function editTask(id, data) {
    try {
      const response = await updateTask(id, data)
      if (response.data.code === 1) {
        ElMessage.success('任务更新成功')
        return true
      } else {
        ElMessage.error(response.data.msg || '更新任务失败')
        return false
      }
    } catch (error) {
      ElMessage.error('更新任务失败: ' + error.message)
      return false
    }
  }

  /**
   * 删除任务
   * @param {string} id - 任务ID
   * @returns {Promise<boolean>} - 是否成功
   */
  async function removeTask(id) {
    try {
      const response = await deleteTask(id)
      if (response.data.code === 1) {
        ElMessage.success('任务删除成功')
        return true
      } else {
        ElMessage.error(response.data.msg || '删除任务失败')
        return false
      }
    } catch (error) {
      ElMessage.error('删除任务失败: ' + error.message)
      return false
    }
  }

  /**
   * 指派任务
   * @param {string} id - 任务ID
   * @param {Object} data - 指派信息
   * @returns {Promise<boolean>} - 是否成功
   */
  async function assignTaskToShift(id, data) {
    try {
      const response = await assignTask(id, data)
      if (response.data.code === 1) {
        ElMessage.success('任务指派成功')
        return true
      } else {
        ElMessage.error(response.data.msg || '指派任务失败')
        return false
      }
    } catch (error) {
      ElMessage.error('指派任务失败: ' + error.message)
      return false
    }
  }

  /**
   * 搜索任务
   * @param {Object} params - 搜索参数
   * @returns {Promise<boolean>} - 是否成功
   */
  async function searchTaskList(params) {
    loading.value = true
    try {
      const response = await searchTasks(params)
      if (response.data.code === 1) {
        taskList.value = response.data.data
        return true
      } else {
        ElMessage.error(response.data.msg || '搜索任务失败')
        return false
      }
    } catch (error) {
      ElMessage.error('搜索任务失败: ' + error.message)
      return false
    } finally {
      loading.value = false
    }
  }

  return {
    taskList,
    loading,
    fetchTaskList,
    addNewTask,
    editTask,
    removeTask,
    assignTaskToShift,
    searchTaskList
  }
})